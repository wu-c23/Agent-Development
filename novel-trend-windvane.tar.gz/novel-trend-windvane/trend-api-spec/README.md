# trend-api-spec

本目录提供“全网风向标”的本地 FastAPI 示例服务，用来连接爬虫 JSONL 数据和 React 趋势大屏。

## 能力

- 读取 `crawler-engine-v1.0/data/*.jsonl`，聚合为前端大屏数据。
- 提供 `/api/trends/dashboard` 和拆分趋势接口。
- `heatCurve` 只统计历史月票榜，并按作品月票数累加到每个细标签，单位为 `k`。
- `genreCloudTimeline` 按月份生成流派词云，用于观察流派热度重心迁移。
- `/api/debug/monthly-coverage` 可检查 `20261` 到 `20265` 是否都采集到，以及每个月是否达到 200 条。
- 提供 `/api/crawler/run`，允许前端按钮触发预定义爬虫任务。
- 只执行固定目标：`zongheng` 或 `all`，不会接收任意 shell 命令。
- 默认只读取最新 JSONL 文件，避免早期试采或旧的不完整文件污染展示；如果确认历史文件都干净，可设置 `TREND_READ_MODE=all`。

## WSL 启动

```bash
cd /mnt/c/Users/86136/Documents/Codex/2026-05-27/goal-ai-python-scrapy-scrapy-cluster/novel-trend-windvane/trend-api-spec
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
ALLOW_CRAWLER_RUN=true CRAWLER_RUN_MODE=docker uvicorn fastapi_demo:app --host 127.0.0.1 --port 8000
```

前端 `.env.local`：

```env
VITE_USE_MOCK=false
VITE_TREND_API_BASE_URL=http://127.0.0.1:8000
```

然后在前端页面点击“采集更新”即可触发纵横榜单采集，采集完成后会自动刷新大屏。

检查月票榜覆盖情况：

```bash
curl http://127.0.0.1:8000/api/debug/monthly-coverage
```

## 安全边界

- API 建议只绑定 `127.0.0.1`，不要暴露到校园网或公网。
- 采集任务只访问公开榜单页面/API，不绕过登录、验证码或付费墙。
- 起点目前仍暂缓自动采集，默认 `ENABLE_QIDIAN=false`。
