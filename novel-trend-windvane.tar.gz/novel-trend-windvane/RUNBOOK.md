# 交付运行指南

本文档面向拿到项目压缩包后的执行者，所有命令均按 WSL 环境编写。

## 1. 前置环境

需要准备：

- WSL 2
- Docker Desktop，并开启当前 WSL 发行版集成
- Node.js 18+
- Python 3.10+
- npm

建议只在本机访问服务，FastAPI 使用 `127.0.0.1:8000`，前端使用 `127.0.0.1:5173`。

## 2. 解压或复制项目

如果收到的是压缩包：

```bash
tar -xzf novel-trend-windvane.tar.gz
cd novel-trend-windvane
```

如果收到的是整个目录，直接进入项目根目录：

```bash
cd /path/to/novel-trend-windvane
```

## 3. 采集纵横榜单数据

```bash
cd crawler-engine-v1.0
docker compose --profile manual run --build --rm crawler-zongheng
```

采集结果会写入：

```text
crawler-engine-v1.0/data/trend_items_zongheng_trends_YYYYMMDDTHHMMSSZ.jsonl
```

当前自动采集范围：

- 纵横 2026 年 1-5 月月票榜，每月 10 页共 200 条
- 纵横畅销榜
- 纵横推荐榜
- 纵横点击榜
- 详情页细标签补全

起点暂不自动采集，也不会在前端平台对比中展示。

## 4. 启动 FastAPI

新终端中执行：

```bash
cd /path/to/novel-trend-windvane/trend-api-spec

python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

export TREND_DATA_DIR=../crawler-engine-v1.0/data
export CRAWLER_DIR=../crawler-engine-v1.0
export ALLOW_CRAWLER_RUN=true

uvicorn fastapi_demo:app --host 127.0.0.1 --port 8000 --reload
```

检查月票榜覆盖情况：

```bash
curl http://127.0.0.1:8000/api/debug/monthly-coverage
```

理想状态：

- `20261` 到 `20265` 都存在
- 每个月 `records` 为 `200`
- `isComplete` 为 `true`

## 5. 启动前端大屏

新终端中执行：

```bash
cd /path/to/novel-trend-windvane/visual-dashboard-component
npm install
npm run dev -- --host 0.0.0.0
```

浏览器打开：

```text
http://127.0.0.1:5173
```

前端默认读取：

```env
VITE_USE_MOCK=false
VITE_TREND_API_BASE_URL=http://127.0.0.1:8000
```

如果没有 `.env.local`，可创建：

```bash
cp .env.example .env.local
```

## 6. 打包转交项目

如果需要把项目交给其他执行者，可在项目上级目录执行：

```bash
tar \
  --exclude='novel-trend-windvane/visual-dashboard-component/node_modules' \
  --exclude='novel-trend-windvane/trend-api-spec/.venv' \
  --exclude='novel-trend-windvane/crawler-engine-v1.0/.scrapy' \
  -czf novel-trend-windvane.tar.gz \
  novel-trend-windvane
```

如果希望对方打开后直接看到当前采集结果，保留 `crawler-engine-v1.0/data/*.jsonl`。

如果希望对方重新采集，删除 `crawler-engine-v1.0/data/*.jsonl` 后再打包即可。

## 7. 常见问题

如果 Docker 命令不存在，先确认 Docker Desktop 已开启 WSL integration。

如果前端能打开但没有真实数据，先检查 API：

```bash
curl http://127.0.0.1:8000/api/health
curl http://127.0.0.1:8000/api/debug/monthly-coverage
```

如果月票趋势没有变化，优先确认最新 JSONL 是否来自修正后的爬虫。新版爬虫会把历史月份传为纵横接口的 `rankNo=20261..20265`，月票数只来自对应月份榜单接口。
