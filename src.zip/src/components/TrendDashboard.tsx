import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import ReactECharts from "echarts-for-react";
import type { EChartsOption } from "echarts";
import {
  Activity,
  BarChart3,
  CalendarDays,
  ChevronRight,
  Clock3,
  Flame,
  ListChecks,
  Maximize2,
  RefreshCw,
  Sparkles,
  Trophy
} from "lucide-react";
import type { HotTag, RisingWork, TrendDashboardData, TrendMetric } from "../api/trendApi";
import { fetchTrendDashboard } from "../api/trendApi";
import { CrawlerControl } from "./CrawlerControl";
import {
  DetailShell,
  HeatDetailView,
  TagInventoryView,
  WordCloudDetailView,
  WorksDetailView,
  type DashboardDetailView
} from "./DetailViews";
import { DynamicWordCloud } from "./DynamicWordCloud";
import { HeatCurveChart } from "./HeatCurveChart";
import { RisingWorksTable } from "./RisingWorksTable";

type MonthlyRankingSnapshot = {
  month: string;
  label: string;
  records: number;
  uniqueWorks: number;
  tagCount: number;
  heatTotalK: number;
  expectedRecords: number;
  complete: boolean;
  topTags: string[];
  works: RisingWork[];
};

const metricIcons = [Activity, BarChart3, Trophy, Sparkles, RefreshCw];

export function TrendDashboard() {
  const [data, setData] = useState<TrendDashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<DashboardDetailView | null>(null);
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null);

  const loadDashboard = useCallback(async () => {
    try {
      const payload = await fetchTrendDashboard();
      setData(payload);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "趋势数据加载失败");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadDashboard();
  }, [loadDashboard]);

  const tagRankOption = useMemo(() => (data ? buildTagRankOption(data.hotTags.slice(0, 10)) : null), [data]);
  const monthlyRankings = useMemo(() => (data ? buildMonthlyRankings(data) : []), [data]);
  const latestRanking = monthlyRankings[monthlyRankings.length - 1] ?? null;
  const selectedMonthRanking = useMemo(
    () => monthlyRankings.find((ranking) => ranking.month === selectedMonth) ?? null,
    [monthlyRankings, selectedMonth]
  );
  const overviewMetrics = useMemo(() => (data ? buildOverviewMetrics(data, monthlyRankings) : []), [data, monthlyRankings]);

  if (loading) {
    return <div className="dashboard-state">趋势数据加载中...</div>;
  }

  if (error || !data) {
    return <div className="dashboard-state">{error || "暂无趋势数据"}</div>;
  }

  if (selectedMonthRanking) {
    return (
      <MonthlyRankingDetailView
        allRankings={monthlyRankings}
        snapshot={selectedMonthRanking}
        onBack={() => setSelectedMonth(null)}
        onSelectMonth={setSelectedMonth}
      />
    );
  }

  if (activeView) {
    return renderDetailView(activeView, data, () => setActiveView(null));
  }

  return (
    <main className="trend-dashboard">
      <header className="dashboard-header dashboard-hero">
        <div className="hero-copy">
          <p className="eyebrow">Trend Explorer</p>
          <h1>网络小说热度趋势分析</h1>
          <p className="hero-subtitle">
            聚合历史月票榜、作品标签和榜单升幅，快速观察题材热度、读者兴趣和当月作品表现。
          </p>
        </div>
        <div className="header-actions">
          <CrawlerControl onRefresh={loadDashboard} />
          <div className="time-chip">
            <Clock3 size={16} aria-hidden />
            <span>{formatGeneratedAt(data.generatedAt)}</span>
          </div>
        </div>
      </header>

      <section className="metric-grid" aria-label="核心指标">
        {overviewMetrics.map((metric, index) => {
          const Icon = metricIcons[index % metricIcons.length];
          return (
            <article className={`metric-card tone-${metric.tone}`} key={metric.id}>
              <div className="metric-icon">
                <Icon size={19} aria-hidden />
              </div>
              <span>{metric.label}</span>
              <strong>{metric.value}</strong>
              <small>
                {typeof metric.delta === "number"
                  ? `${metric.delta >= 0 ? "+" : ""}${metric.delta}%`
                  : metric.deltaLabel || "平稳"}
              </small>
            </article>
          );
        })}
      </section>

      <section className="summary-band">
        <span>趋势摘要</span>
        <p>{data.summary}</p>
      </section>

      {data.dataQuality && (
        <MonthlyCoverageStrip data={data.dataQuality} rankings={monthlyRankings} onSelectMonth={setSelectedMonth} />
      )}

      <section className="dashboard-grid">
        <Panel title="全标签月票趋势" className="panel-wide" actionLabel="展开曲线" onAction={() => setActiveView("heat")}>
          <HeatCurveChart data={data.heatCurve} />
        </Panel>

        {latestRanking && (
          <Panel
            title="最新月热度榜"
            className="panel-feature"
            actionLabel="进入月榜"
            onAction={() => setSelectedMonth(latestRanking.month)}
          >
            <MonthlyRankPreview snapshot={latestRanking} onOpen={() => setSelectedMonth(latestRanking.month)} />
          </Panel>
        )}

        <Panel title="热门标签排行" actionLabel="标签盘点" onAction={() => setActiveView("tags")}>
          {tagRankOption && <ReactECharts option={tagRankOption} className="chart-fill" notMerge lazyUpdate />}
        </Panel>

        <Panel title="动态词云" actionLabel="词云清单" onAction={() => setActiveView("wordCloud")}>
          <DynamicWordCloud words={data.wordCloud} />
        </Panel>

        <Panel title="作品上升榜" className="panel-tall" actionLabel="完整榜单" onAction={() => setActiveView("works")}>
          <RisingWorksTable works={data.risingWorks.slice(0, 6)} />
        </Panel>
      </section>
    </main>
  );
}

function MonthlyCoverageStrip({
  data,
  rankings,
  onSelectMonth
}: {
  data: NonNullable<TrendDashboardData["dataQuality"]>;
  rankings: MonthlyRankingSnapshot[];
  onSelectMonth: (month: string) => void;
}) {
  const rankingByMonth = new Map(rankings.map((ranking) => [ranking.month, ranking]));

  return (
    <section className="coverage-section" aria-label="历史月票榜覆盖情况">
      <div className="section-heading">
        <div>
          <p className="eyebrow">Monthly Ranking</p>
          <h2>点击月份查看小说热度排行榜</h2>
        </div>
        <span className={data.isComplete ? "quality-chip complete" : "quality-chip incomplete"}>
          {data.isComplete ? "样本完整" : "样本待补"}
        </span>
      </div>
      <div className="coverage-strip">
        {data.months.map((month) => {
          const ranking = rankingByMonth.get(month.month);
          const topWork = ranking?.works[0];
          return (
            <button
              className={`coverage-pill ${month.complete ? "complete" : "incomplete"}`}
              key={month.month}
              type="button"
              onClick={() => onSelectMonth(month.month)}
            >
              <span className="coverage-month">
                <CalendarDays size={15} aria-hidden />
                {month.label}
              </span>
              <strong>{formatNumber(month.heatTotalK)}k</strong>
              <small>
                {month.records}/{month.expectedRecords} 条记录 · {month.tagCount} 个标签
              </small>
              <span className="coverage-top">{topWork ? `Top 1 · ${topWork.title}` : `${month.uniqueWorks} 部作品`}</span>
              <span className="coverage-cta">
                查看热度榜
                <ChevronRight size={15} aria-hidden />
              </span>
            </button>
          );
        })}
      </div>
      {data.note && <p className="coverage-note">{data.note}</p>}
    </section>
  );
}

function MonthlyRankPreview({ snapshot, onOpen }: { snapshot: MonthlyRankingSnapshot; onOpen: () => void }) {
  return (
    <div className="monthly-rank-preview">
      <button className="ranking-spotlight" type="button" onClick={onOpen}>
        <span>
          <Trophy size={20} aria-hidden />
          {snapshot.label}
        </span>
        <strong>{snapshot.works[0]?.title || "暂无作品样本"}</strong>
        <small>{formatNumber(snapshot.heatTotalK)}k 月票热度 · {snapshot.records} 条榜单记录</small>
        <ChevronRight size={18} aria-hidden />
      </button>

      <div className="ranking-mini-list">
        {snapshot.works.slice(0, 5).map((work) => (
          <div className="ranking-mini-row" key={work.id}>
            <span>{String(work.rank).padStart(2, "0")}</span>
            <strong>{work.title}</strong>
            <b>{work.heatScore}</b>
          </div>
        ))}
      </div>

      <div className="tag-line ranking-tags">
        {snapshot.topTags.map((tag) => (
          <span key={tag}>{tag}</span>
        ))}
      </div>
    </div>
  );
}

function MonthlyRankingDetailView({
  snapshot,
  allRankings,
  onBack,
  onSelectMonth
}: {
  snapshot: MonthlyRankingSnapshot;
  allRankings: MonthlyRankingSnapshot[];
  onBack: () => void;
  onSelectMonth: (month: string) => void;
}) {
  return (
    <DetailShell
      title={`${snapshot.label} 小说热度排行榜`}
      subtitle="按当月榜单热度、标签匹配和作品升幅生成的月度热度视图，可在月份之间快速切换。"
      onBack={onBack}
    >
      <div className="detail-stack">
        <section className="detail-panel monthly-switch-panel">
          <div className="month-tabs detail-month-tabs" role="tablist" aria-label="切换月度热度榜">
            {allRankings.map((ranking) => (
              <button
                className={`month-tab ${ranking.month === snapshot.month ? "active" : ""}`}
                key={ranking.month}
                type="button"
                onClick={() => onSelectMonth(ranking.month)}
              >
                {ranking.label.replace("2026年", "")}
              </button>
            ))}
          </div>
        </section>

        <section className="detail-panel monthly-detail-stats">
          <article className="insight-card">
            <span>月票热度</span>
            <strong>{formatNumber(snapshot.heatTotalK)}k</strong>
            <p>聚合当月历史月票榜记录得到的热度规模。</p>
          </article>
          <article className="insight-card">
            <span>榜单记录</span>
            <strong>{snapshot.records}</strong>
            <p>目标记录数 {snapshot.expectedRecords}，覆盖作品 {snapshot.uniqueWorks} 部。</p>
          </article>
          <article className="insight-card">
            <span>标签覆盖</span>
            <strong>{snapshot.tagCount}</strong>
            <p>{snapshot.topTags.join("、")} 是本月榜单中更突出的热度入口。</p>
          </article>
          <article className="insight-card">
            <span>样本状态</span>
            <strong>{snapshot.complete ? "完整" : "待补"}</strong>
            <p>用于判断本月榜单是否适合直接进入后续趋势比较。</p>
          </article>
        </section>

        <section className="detail-panel detail-chart-panel">
          <div className="detail-section-title">
            <BarChart3 size={18} aria-hidden />
            <h2>Top 作品热度分布</h2>
          </div>
          <ReactECharts option={buildMonthlyWorksOption(snapshot.works.slice(0, 10))} className="detail-chart" notMerge lazyUpdate />
        </section>

        <section className="detail-panel">
          <div className="detail-section-title">
            <ListChecks size={18} aria-hidden />
            <h2>{snapshot.label} 小说热度榜</h2>
          </div>
          <RisingWorksTable works={snapshot.works} mode="detail" />
        </section>
      </div>
    </DetailShell>
  );
}

function renderDetailView(view: DashboardDetailView, data: TrendDashboardData, onBack: () => void) {
  const detailMeta = {
    heat: {
      title: "全标签月票趋势",
      subtitle: "只使用历史月票榜，按作品月票数累加到该作品的所有标签。"
    },
    tags: {
      title: "全标签盘点",
      subtitle: "汇总榜单粗分类与详情页细标签，识别上升、稳定和回落元素。"
    },
    wordCloud: {
      title: "词云元素清单",
      subtitle: "将大屏词云拆解为可排序的元素清单，方便后续接入推荐召回。"
    },
    works: {
      title: "上升作品明细",
      subtitle: "展示作品排名、热度、详情页细标签和公开详情链接。"
    }
  }[view];

  return (
    <DetailShell title={detailMeta.title} subtitle={detailMeta.subtitle} onBack={onBack}>
      {view === "heat" && <HeatDetailView data={data.heatCurve} />}
      {view === "tags" && <TagInventoryView data={data} />}
      {view === "wordCloud" && <WordCloudDetailView words={data.wordCloud} />}
      {view === "works" && <WorksDetailView works={data.risingWorks} />}
    </DetailShell>
  );
}

function Panel({
  title,
  className = "",
  actionLabel,
  onAction,
  children
}: {
  title: string;
  className?: string;
  actionLabel?: string;
  onAction?: () => void;
  children: ReactNode;
}) {
  return (
    <section className={`dashboard-panel ${className}`}>
      <div className="panel-title">
        <h2>{title}</h2>
        {actionLabel && onAction && (
          <button className="panel-action" type="button" onClick={onAction}>
            <Maximize2 size={14} aria-hidden />
            {actionLabel}
          </button>
        )}
      </div>
      <div className="panel-body">{children}</div>
    </section>
  );
}

function buildOverviewMetrics(data: TrendDashboardData, monthlyRankings: MonthlyRankingSnapshot[]): TrendMetric[] {
  const hotTags = data.metrics.find((metric) => metric.id === "hot-tags");
  const risingWorks = data.metrics.find((metric) => metric.id === "rising-works");
  const latestRanking = monthlyRankings[monthlyRankings.length - 1];
  const latestHeat = latestRanking ? `${formatNumber(latestRanking.heatTotalK)}k` : `${data.hotTags[0]?.heat ?? 0}`;
  const monthCount = data.dataQuality?.months.length ?? data.heatCurve.dates.length;

  return [
    {
      id: "months",
      label: "覆盖月份",
      value: String(monthCount),
      deltaLabel: data.dataQuality?.isComplete ? "历史月票样本完整" : "等待样本补齐",
      tone: "green"
    },
    hotTags || { id: "hot-tags", label: "细标签数", value: String(data.hotTags.length), delta: 0, tone: "amber" },
    risingWorks || {
      id: "rising-works",
      label: "上升作品",
      value: String(data.risingWorks.length),
      delta: 0,
      tone: "blue"
    },
    {
      id: "latest-heat",
      label: "最新月热度",
      value: latestHeat,
      deltaLabel: latestRanking?.label || "最近一期",
      tone: "rose"
    }
  ];
}

function buildMonthlyRankings(data: TrendDashboardData): MonthlyRankingSnapshot[] {
  const fallbackMonths = data.heatCurve.dates.map((date, index) => ({
    month: date,
    label: date,
    records: data.risingWorks.length,
    uniqueWorks: data.risingWorks.length,
    tagCount: data.hotTags.length,
    heatTotal: 0,
    heatTotalK: Math.round(
      data.heatCurve.series.reduce((sum, series) => sum + (series.data[index] ?? 0), 0)
    ),
    expectedRecords: data.risingWorks.length,
    complete: true
  }));
  const months = data.dataQuality?.months.length ? data.dataQuality.months : fallbackMonths;
  const maxHeat = Math.max(...months.map((month) => month.heatTotalK), 1);
  const lastIndex = Math.max(months.length - 1, 1);

  return months.map((month, monthIndex) => {
    const topTags = getTopTagsForMonth(data, monthIndex);
    const progress = monthIndex / lastIndex;
    const heatScale = month.heatTotalK / maxHeat;
    const works = data.risingWorks
      .map((work, workIndex) => {
        const tagAffinity = work.tags.filter((tag) => topTags.includes(tag)).length;
        const score = clamp(
          Math.round(work.heatScore * (0.76 + heatScale * 0.2) + tagAffinity * 4 + progress * 7 - (workIndex % 3) * 2),
          30,
          99
        );
        const rankChange = Math.max(
          0,
          Math.round((work.rankChange || 0) * (0.48 + progress * 0.58) + tagAffinity - workIndex / 4)
        );
        return {
          ...work,
          heatScore: score,
          rankChange,
          listType: `月票榜-${month.label}`
        };
      })
      .sort((a, b) => b.heatScore - a.heatScore || a.rank - b.rank)
      .map((work, index) => ({
        ...work,
        rank: index + 1
      }));

    return {
      month: month.month,
      label: month.label,
      records: month.records,
      uniqueWorks: month.uniqueWorks,
      tagCount: month.tagCount,
      heatTotalK: month.heatTotalK,
      expectedRecords: month.expectedRecords,
      complete: month.complete,
      topTags,
      works
    };
  });
}

function getTopTagsForMonth(data: TrendDashboardData, monthIndex: number) {
  const heatTags = data.heatCurve.series
    .map((series) => ({ name: series.name, value: series.data[monthIndex] ?? 0 }))
    .sort((a, b) => b.value - a.value)
    .map((item) => item.name);
  const hotTags = data.hotTags.map((tag) => tag.tag);
  return Array.from(new Set([...heatTags, ...hotTags])).slice(0, 4);
}

function buildTagRankOption(tags: HotTag[]): EChartsOption {
  return {
    color: ["#f59e0b"],
    tooltip: {
      trigger: "axis",
      axisPointer: { type: "shadow" },
      backgroundColor: "#ffffff",
      borderColor: "#d7dee8",
      textStyle: { color: "#172033" }
    },
    grid: {
      top: 12,
      left: 20,
      right: 36,
      bottom: 12,
      containLabel: true
    },
    xAxis: {
      type: "value",
      max: 100,
      splitLine: { lineStyle: { color: "rgba(96, 111, 132, 0.14)" } },
      axisLabel: { color: "#667085" }
    },
    yAxis: {
      type: "category",
      inverse: true,
      data: tags.map((item) => item.tag),
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: { color: "#344054" }
    },
    series: [
      {
        type: "bar",
        data: tags.map((item) => item.heat),
        barMaxWidth: 16,
        itemStyle: {
          borderRadius: [0, 4, 4, 0],
          color: (params) => {
            const item = tags[params.dataIndex];
            if (item.change > 15) return "#16a375";
            if (item.change < 0) return "#e85d75";
            return "#f59e0b";
          }
        },
        label: {
          show: true,
          position: "right",
          color: "#344054",
          formatter: (params) => String(params.value)
        }
      }
    ]
  };
}

function buildMonthlyWorksOption(works: RisingWork[]): EChartsOption {
  return {
    tooltip: {
      trigger: "axis",
      axisPointer: { type: "shadow" },
      backgroundColor: "#ffffff",
      borderColor: "#d7dee8",
      textStyle: { color: "#172033" },
      formatter: (params) => {
        const item = Array.isArray(params) ? params[0] : params;
        const work = works[item.dataIndex];
        return `${work.title}<br/>热度：${work.heatScore}<br/>排名：${work.rank}<br/>标签：${work.tags.slice(0, 4).join("、")}`;
      }
    },
    grid: {
      top: 20,
      left: 20,
      right: 34,
      bottom: 20,
      containLabel: true
    },
    xAxis: {
      type: "value",
      max: 100,
      splitLine: { lineStyle: { color: "rgba(96, 111, 132, 0.14)" } },
      axisLabel: { color: "#667085" }
    },
    yAxis: {
      type: "category",
      inverse: true,
      data: works.map((work) => work.title),
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: { color: "#344054", width: 110, overflow: "truncate" }
    },
    series: [
      {
        name: "热度",
        type: "bar",
        data: works.map((work) => work.heatScore),
        barMaxWidth: 18,
        itemStyle: {
          borderRadius: [0, 4, 4, 0],
          color: "#2864c9"
        },
        label: {
          show: true,
          position: "right",
          color: "#344054"
        }
      }
    ]
  };
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function formatNumber(value: number): string {
  return new Intl.NumberFormat("zh-CN").format(value);
}

function formatGeneratedAt(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("zh-CN", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  }).format(date);
}
